﻿namespace Lab1_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonRight = new Button();
            buttonLeft = new Button();
            buttonUp = new Button();
            buttonDown = new Button();
            buttonStart = new Button();
            buttonStop = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            intervalTextBox = new TextBox();
            textBox1 = new TextBox();
            labelCounter = new Label();
            SuspendLayout();
            // 
            // buttonRight
            // 
            buttonRight.Location = new Point(460, 306);
            buttonRight.Name = "buttonRight";
            buttonRight.Size = new Size(75, 23);
            buttonRight.TabIndex = 0;
            buttonRight.Text = "Right";
            buttonRight.UseVisualStyleBackColor = true;
            buttonRight.Click += buttonRight_Click;
            // 
            // buttonLeft
            // 
            buttonLeft.Location = new Point(209, 306);
            buttonLeft.Name = "buttonLeft";
            buttonLeft.Size = new Size(75, 23);
            buttonLeft.TabIndex = 1;
            buttonLeft.Text = "Left";
            buttonLeft.UseVisualStyleBackColor = true;
            buttonLeft.Click += buttonLeft_Click;
            // 
            // buttonUp
            // 
            buttonUp.Location = new Point(331, 249);
            buttonUp.Name = "buttonUp";
            buttonUp.Size = new Size(75, 23);
            buttonUp.TabIndex = 2;
            buttonUp.Text = "Up";
            buttonUp.UseVisualStyleBackColor = true;
            buttonUp.Click += buttonUp_Click;
            // 
            // buttonDown
            // 
            buttonDown.Location = new Point(331, 371);
            buttonDown.Name = "buttonDown";
            buttonDown.Size = new Size(75, 23);
            buttonDown.TabIndex = 3;
            buttonDown.Text = "Down";
            buttonDown.UseVisualStyleBackColor = true;
            buttonDown.Click += buttonDown_Click;
            // 
            // buttonStart
            // 
            buttonStart.Location = new Point(209, 87);
            buttonStart.Name = "buttonStart";
            buttonStart.Size = new Size(75, 23);
            buttonStart.TabIndex = 4;
            buttonStart.Text = "Start";
            buttonStart.UseVisualStyleBackColor = true;
            buttonStart.Click += buttonStart_Click;
            // 
            // buttonStop
            // 
            buttonStop.Location = new Point(460, 87);
            buttonStop.Name = "buttonStop";
            buttonStop.Size = new Size(75, 23);
            buttonStop.TabIndex = 5;
            buttonStop.Text = "Stop";
            buttonStop.UseVisualStyleBackColor = true;
            buttonStop.Click += buttonStop_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // intervalTextBox
            // 
            intervalTextBox.Location = new Point(209, 148);
            intervalTextBox.Name = "intervalTextBox";
            intervalTextBox.Size = new Size(326, 23);
            intervalTextBox.TabIndex = 6;
            intervalTextBox.TextChanged += intervalTextBox_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(209, 30);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(326, 23);
            textBox1.TabIndex = 7;
            // 
            // labelCounter
            // 
            labelCounter.AutoSize = true;
            labelCounter.Location = new Point(356, 90);
            labelCounter.Name = "labelCounter";
            labelCounter.Size = new Size(0, 15);
            labelCounter.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labelCounter);
            Controls.Add(textBox1);
            Controls.Add(intervalTextBox);
            Controls.Add(buttonStop);
            Controls.Add(buttonStart);
            Controls.Add(buttonDown);
            Controls.Add(buttonUp);
            Controls.Add(buttonLeft);
            Controls.Add(buttonRight);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonRight;
        private Button buttonLeft;
        private Button buttonUp;
        private Button buttonDown;
        private Button buttonStart;
        private Button buttonStop;
        private System.Windows.Forms.Timer timer1;
        private TextBox intervalTextBox;
        private TextBox textBox1;
        private Label labelCounter;
    }
}
