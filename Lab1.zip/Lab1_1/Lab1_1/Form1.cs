namespace Lab1_1
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonRight_Click(object sender, EventArgs e)
        {
            this.Left += 10;

            MessageBox.Show("'RIGHT' button was pressed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonLeft_Click(object sender, EventArgs e)
        {
            this.Left -= 10;

            MessageBox.Show("'LEFT' button was pressed", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        }

        private void buttonUp_Click(object sender, EventArgs e)
        {
            this.Top -= 10;

            DialogResult result = MessageBox.Show("'UP' button was pressed! Do you want to continue?", "Confirm", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                textBox1.Text = "You chose yes";
            }
            else if (result == DialogResult.No)
            {
                textBox1.Text = "You chose no";
            }
            else
            {
                textBox1.Text = "You pressed cancel";
            }
        }

        private void buttonDown_Click(object sender, EventArgs e)
        {
            this.Top += 10;

            DialogResult result = MessageBox.Show("'DOWN' button was pressed! Do you want to try again?", "Trying again", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);

            if (result == DialogResult.Retry)
            {
                textBox1.Text = "You chose retry";
            }
            else
            {
                textBox1.Text = "Cancel selected";
            }
        }

        int counter = 0;

        private void buttonStart_Click(object sender, EventArgs e)
        {
            counter = 0;
            timer1.Start();

            textBox1.Text = "Timer started";
            labelCounter.Text = "Ticks: " + counter;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();

            textBox1.Text = "Timer stopped";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter++;
            labelCounter.Text = "Ticks: " + counter;

            this.BackColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
        }

        private void intervalTextBox_TextChanged(object sender, EventArgs e)
        {
            int newInterval;

            if (int.TryParse(intervalTextBox.Text, out newInterval))
            {
                if (newInterval < 50)
                {
                    newInterval = 50;
                }

                timer1.Interval = newInterval;
                textBox1.Text = "Timer interval: " + newInterval + " ms";
            }
            else
            {
                textBox1.Text = "Enter a valid number";
            }
        }
    }
}
