﻿namespace Lab1_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonLeft = new Button();
            buttonCenter = new Button();
            buttonRight = new Button();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // buttonLeft
            // 
            buttonLeft.Location = new Point(326, 553);
            buttonLeft.Margin = new Padding(3, 4, 3, 4);
            buttonLeft.Name = "buttonLeft";
            buttonLeft.Size = new Size(86, 31);
            buttonLeft.TabIndex = 0;
            buttonLeft.Text = "Left";
            buttonLeft.UseVisualStyleBackColor = true;
            buttonLeft.Click += buttonLeft_Click;
            // 
            // buttonCenter
            // 
            buttonCenter.Location = new Point(418, 553);
            buttonCenter.Margin = new Padding(3, 4, 3, 4);
            buttonCenter.Name = "buttonCenter";
            buttonCenter.Size = new Size(86, 31);
            buttonCenter.TabIndex = 1;
            buttonCenter.Text = "Center";
            buttonCenter.UseVisualStyleBackColor = true;
            buttonCenter.Click += buttonCenter_Click;
            // 
            // buttonRight
            // 
            buttonRight.Location = new Point(511, 553);
            buttonRight.Margin = new Padding(3, 4, 3, 4);
            buttonRight.Name = "buttonRight";
            buttonRight.Size = new Size(86, 31);
            buttonRight.TabIndex = 2;
            buttonRight.Text = "Right";
            buttonRight.UseVisualStyleBackColor = true;
            buttonRight.Click += buttonRight_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(422, 479);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 3;
            label1.Text = "Moving Text";
            // 
            // button1
            // 
            button1.Location = new Point(740, 559);
            button1.Name = "button1";
            button1.Size = new Size(162, 29);
            button1.TabIndex = 4;
            button1.Text = "Click if you're straight";
            button1.UseVisualStyleBackColor = true;
            button1.MouseEnter += button1_MouseEnter;
            // 
            // button2
            // 
            button2.Location = new Point(12, 559);
            button2.Name = "button2";
            button2.Size = new Size(162, 29);
            button2.TabIndex = 5;
            button2.Text = "Move Forms";
            button2.UseVisualStyleBackColor = true;
            button2.MouseEnter += button2_MouseEnter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(buttonRight);
            Controls.Add(buttonCenter);
            Controls.Add(buttonLeft);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonLeft;
        private Button buttonCenter;
        private Button buttonRight;
        private Label label1;
        private Button button1;
        private Button button2;
    }
}
