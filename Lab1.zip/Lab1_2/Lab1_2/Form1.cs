using System;
using System.Drawing;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace Lab1_2
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonLeft_Click(object sender, EventArgs e)
        {
            label1.Location = new Point(10, label1.Location.Y);
        }

        private void buttonCenter_Click(object sender, EventArgs e)
        {
            int x = (this.ClientSize.Width - label1.Width) / 2;
            label1.Location = new Point(x, label1.Location.Y);
        }

        private void buttonRight_Click(object sender, EventArgs e)
        {
            int x = this.ClientSize.Width - label1.Width - 10;
            label1.Location = new Point(x, label1.Location.Y);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            int maxX = this.ClientSize.Width - button1.Width;
            int maxY = this.ClientSize.Height - button1.Height;

            int newX = rnd.Next(0, maxX);
            int newY = rnd.Next(0, maxY);

            button1.Location = new Point(newX, newY);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            if (button1.Bottom + 30 < this.ClientSize.Height)
            {
                button1.Location = new Point(button1.Location.X, button1.Location.Y + 30);
            }
        }
    }
}
